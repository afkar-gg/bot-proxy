clear && rm rblx.js && wget https://raw.githubusercontent.com/afkar-gg/bot-proxy/refs/heads/main/rblx.js && clear && node rblx.js
